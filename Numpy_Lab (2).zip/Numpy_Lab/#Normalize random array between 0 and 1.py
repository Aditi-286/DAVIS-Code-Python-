#Normalize random array between 0 and 1
import numpy as np

random_array = np.random.rand(10)

normalized_array = (random_array - random_array.min()) / (random_array.max() - random_array.min())

print("Original Array:")
print(random_array)

print("\nNormalized Array:")
print(normalized_array)