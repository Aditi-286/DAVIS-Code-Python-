#Extract middle 3×3 sub-matrix

import numpy as np

numbers_array = np.arange(1,26)

matrix_5x5 = numbers_array.reshape(5,5)

sub_matrix = matrix_5x5[1:4,1:4]

print(sub_matrix)