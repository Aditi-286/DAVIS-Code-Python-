#Create a 5×5 matrix with random integers and find min & max
import numpy as np

random_matrix = np.random.randint(1, 101, (5,5))

minimum_value = random_matrix.min()
maximum_value = random_matrix.max()

print("Matrix:")
print(random_matrix)

print("\nMin =", minimum_value)
print("Max =", maximum_value)