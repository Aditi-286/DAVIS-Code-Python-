#Reverse the array
import numpy as np

numbers_array = np.arange(1,11)

reversed_array = numbers_array[::-1]

print(reversed_array)