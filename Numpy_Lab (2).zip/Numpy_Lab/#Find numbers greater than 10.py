#Find numbers greater than 10
import numpy as np

numbers_array = np.arange(1,16)

greater_than_10 = numbers_array[numbers_array > 10]

print(greater_than_10)