#Create a NumPy array from 1 to 20 and reshape it into a 4×5 matrix
import numpy as np

numbers_array = np.arange(1, 21)
reshaped_matrix = numbers_array.reshape(4, 5)

print(reshaped_matrix)