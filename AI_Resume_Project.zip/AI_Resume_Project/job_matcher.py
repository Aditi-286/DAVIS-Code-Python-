import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def match_jobs(resume_text):
    jobs = pd.read_csv("jobs.csv")

    corpus = jobs['description'].tolist()
    corpus.append(resume_text)

    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform(corpus)

    similarity = cosine_similarity(vectors[-1], vectors[:-1])

    scores = similarity.flatten()

    jobs['score'] = scores

    return jobs.sort_values(by='score', ascending=False)
def extract_skills(text):
    skills = ["python", "java", "sql", "machine learning", "html", "css"]
    
    found_skills = []
    
    for skill in skills:
        if skill in text.lower():
            found_skills.append(skill)
    
    return found_skills