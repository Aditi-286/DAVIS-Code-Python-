from flask import Flask, request
from resume_parser import extract_text_from_pdf
from job_matcher import match_jobs, extract_skills

app = Flask(__name__)

@app.route('/')
def home():
    return '''
    <html>
    <head>
        <title>AI Resume Screener</title>
    </head>
    <body style="font-family: Arial; text-align:center; margin-top:50px;">
        <h1>AI Resume Screening System</h1>
        <p>Upload your resume to get job recommendations</p>
        
        <form method="POST" action="/upload" enctype="multipart/form-data">
            <input type="file" name="resume" style="margin:20px;">
            <br>
            <input type="submit" value="Get Recommendations" 
                   style="padding:10px 20px; background-color:blue; color:white;">
        </form>
    </body>
    </html>
    '''

@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['resume']
    
    text = extract_text_from_pdf(file)
    results = match_jobs(text)
    skills = extract_skills(text)

    output = """
    <html>
    <body style="font-family: Arial; text-align:center;">
    <h2>Top Job Recommendations</h2>
    """

    output += "<h3>Detected Skills:</h3>"
    output += ", ".join(skills)

    for index, row in results.head(3).iterrows():
        output += f"""
        <div style='margin:10px; padding:10px; border:1px solid black;'>
            <h3>{row['title']}</h3>
            <p>Match Score: {row['score']:.2f}</p>
        </div>
        """

    output += "</body></html>"
    return output

if __name__ == '__main__':
    app.run(debug=True)